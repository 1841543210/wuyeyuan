# 影视源配置

`source_night_001` 至 `source_night_040` 共 40 个影视源配置，主文件为 `sources.json`。

上传到 GitHub 后，可通过 Raw 地址供支持该格式的程序读取。
